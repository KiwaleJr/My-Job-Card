# My Job Card v1.0 (Android source)

Brand: My Job Card  
Languages: English + Kiswahili (initial UI; some labels in this MVP remain English)  
Audience: anyone who works  
Pricing: free for now  
Package: `com.myjobcard.app`

## MVP features
- Firebase email/password registration and login
- User-specific Firestore job records
- Multiple jobs on any date
- Expected amount, amount received, outstanding balance
- Paid / Partially paid / Unpaid status calculated from amounts
- Dashboard totals
- English/Swahili language toggle (initial bilingual coverage)

## Firebase setup
1. Open Firebase Console > Authentication > Get started.
2. Enable Email/Password.
3. Create a Cloud Firestore database.
4. Apply these rules:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/jobs/{jobId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```
5. Google login is not yet implemented in this MVP. It requires Firebase Google provider + OAuth Web client ID + SHA-1/SHA-256 signing fingerprints. Do not advertise Google login as working until that is implemented and tested.
6. To build: open this folder in Android Studio, sync Gradle, then Build > Build APK(s).

## Important limitations
- This is Android source code, not a compiled/signed APK.
- Online Firestore access requires internet.
- Before public Play Store release, add Google sign-in, password reset, account deletion, privacy policy, full translations, app icon, testing, Play Console setup and required store disclosures.
- The attached Firebase config should be copied to `app/google-services.json` only if it contains the `com.myjobcard.app` client.
