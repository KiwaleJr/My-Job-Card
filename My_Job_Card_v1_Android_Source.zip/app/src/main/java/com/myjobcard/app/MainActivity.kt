package com.myjobcard.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF142B4A)
private val Green = Color(0xFF16865B)
private val Pale = Color(0xFFF1F5F8)

data class Job(
    val id: String = "",
    val title: String = "",
    val notes: String = "",
    val amount: Long = 0,
    val paidAmount: Long = 0,
    val date: String = ""
) {
    val balance: Long get() = (amount - paidAmount).coerceAtLeast(0)
    val status: String get() = when {
        paidAmount <= 0 -> "Unpaid"
        paidAmount >= amount -> "Paid"
        else -> "Partially paid"
    }
}

class MainActivity : ComponentActivity() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Green)) {
                var user by remember { mutableStateOf(auth.currentUser) }
                var jobs by remember { mutableStateOf(listOf<Job>()) }
                var error by remember { mutableStateOf("") }
                var showAdd by remember { mutableStateOf(false) }
                var swahili by remember { mutableStateOf(false) }

                LaunchedEffect(user?.uid) {
                    val uid = user?.uid ?: return@LaunchedEffect
                    db.collection("users").document(uid).collection("jobs")
                        .orderBy("date", Query.Direction.DESCENDING)
                        .addSnapshotListener { snapshot, e ->
                            if (e != null) { error = e.localizedMessage ?: "Could not load jobs"; return@addSnapshotListener }
                            jobs = snapshot?.documents?.map { d ->
                                Job(d.id, d.getString("title") ?: "", d.getString("notes") ?: "",
                                    d.getLong("amount") ?: 0, d.getLong("paidAmount") ?: 0, d.getString("date") ?: "")
                            } ?: emptyList()
                        }
                }

                if (user == null) {
                    LoginPage(
                        swahili = swahili, onLanguage = { swahili = !swahili }, error = error,
                        onLogin = { email, pass ->
                            auth.signInWithEmailAndPassword(email.trim(), pass).addOnCompleteListener { t ->
                                if (t.isSuccessful) { user = auth.currentUser; error = "" }
                                else error = t.exception?.localizedMessage ?: "Login failed"
                            }
                        },
                        onRegister = { email, pass ->
                            auth.createUserWithEmailAndPassword(email.trim(), pass).addOnCompleteListener { t ->
                                if (t.isSuccessful) { user = auth.currentUser; error = "" }
                                else error = t.exception?.localizedMessage ?: "Registration failed"
                            }
                        }
                    )
                } else {
                    Dashboard(
                        email = user?.email ?: "",
                        jobs = jobs,
                        swahili = swahili,
                        error = error,
                        onLanguage = { swahili = !swahili },
                        onAdd = { showAdd = true },
                        onLogout = { auth.signOut(); user = null; jobs = emptyList() },
                        onPaid = { job, paid ->
                            db.collection("users").document(user!!.uid).collection("jobs")
                                .document(job.id).update("paidAmount", paid)
                        }
                    )
                    if (showAdd) AddJobDialog(
                        swahili = swahili,
                        onDismiss = { showAdd = false },
                        onSave = { title, notes, amount, date ->
                            val data = hashMapOf("title" to title, "notes" to notes, "amount" to amount,
                                "paidAmount" to 0L, "date" to date, "createdAt" to System.currentTimeMillis())
                            db.collection("users").document(user!!.uid).collection("jobs").add(data)
                                .addOnFailureListener { error = it.localizedMessage ?: "Save failed" }
                            showAdd = false
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun LoginPage(
    swahili: Boolean, onLanguage: () -> Unit, error: String,
    onLogin: (String, String) -> Unit, onRegister: (String, String) -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var create by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("My Job Card", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = Navy)
        Text(if (swahili) "Rekodi kazi zako. Fuatilia malipo yako." else "Track your work. Track your money.", color = Green)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), label = { Text("Email") }, singleLine = true)
        OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(), label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true)
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { if (create) onRegister(email, password) else onLogin(email, password) },
            modifier = Modifier.fillMaxWidth(), enabled = email.contains("@") && password.length >= 6
        ) { Text(if (create) "Create account" else "Login") }
        OutlinedButton(onClick = { create = !create }, modifier = Modifier.fillMaxWidth()) {
            Text(if (create) "Already registered? Login" else "Create a new account")
        }
        TextButton(onClick = onLanguage, modifier = Modifier.fillMaxWidth()) {
            Text(if (swahili) "Switch to English" else "Badili kwenda Kiswahili")
        }
        Text("Google sign-in will be enabled after Firebase OAuth setup.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
    }
}

@Composable
private fun Dashboard(
    email: String, jobs: List<Job>, swahili: Boolean, error: String,
    onLanguage: () -> Unit, onAdd: () -> Unit, onLogout: () -> Unit,
    onPaid: (Job, Long) -> Unit
) {
    val expected = jobs.sumOf { it.amount }
    val received = jobs.sumOf { it.paidAmount.coerceAtMost(it.amount) }
    val outstanding = (expected - received).coerceAtLeast(0)
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("My Job Card", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Navy)
                Text(email, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
            Column {
                TextButton(onClick = onLanguage) { Text(if (swahili) "EN" else "SW") }
                TextButton(onClick = onLogout) { Text(if (swahili) "Toka" else "Logout") }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Summary("Expected", expected, Modifier.weight(1f))
            Summary("Received", received, Modifier.weight(1f))
            Summary("Due", outstanding, Modifier.weight(1f))
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(if (swahili) "Kazi zangu" else "My jobs", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            FilledTonalButton(onClick = onAdd) { Icon(Icons.Default.Add, null); Text(if (swahili) "Ongeza" else "Add job") }
        }
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        if (jobs.isEmpty()) {
            Spacer(Modifier.height(24.dp))
            Text(if (swahili) "Bado hakuna kazi. Ongeza kazi yako ya kwanza." else "No jobs yet. Add your first job.", color = Color.Gray)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 10.dp)) {
                items(jobs, key = { it.id }) { job ->
                    var paidInput by remember(job.paidAmount) { mutableStateOf(job.paidAmount.toString()) }
                    Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Pale)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(job.title, fontWeight = FontWeight.Bold)
                                Text("TSh ${job.amount}", color = Green, fontWeight = FontWeight.Bold)
                            }
                            Text(job.date, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                            if (job.notes.isNotBlank()) Text(job.notes)
                            Text("${job.status} • Due: TSh ${job.balance}", color = if (job.balance == 0L) Green else Color(0xFF9A6500))
                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                OutlinedTextField(paidInput, { paidInput = it }, Modifier.weight(1f),
                                    label = { Text(if (swahili) "Kiasi kilicholipwa" else "Amount received") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                                Spacer(Modifier.width(8.dp))
                                Button(onClick = { paidInput.toLongOrNull()?.let { onPaid(job, it.coerceIn(0, job.amount)) } }) {
                                    Text(if (swahili) "Hifadhi" else "Update")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Summary(label: String, amount: Long, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF2F8))) {
        Column(Modifier.padding(9.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            Text("TSh $amount", fontWeight = FontWeight.Bold, color = Navy)
        }
    }
}

@Composable
private fun AddJobDialog(
    swahili: Boolean, onDismiss: () -> Unit,
    onSave: (String, String, Long, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (swahili) "Ongeza kazi" else "Add a job") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text(if (swahili) "Jina la kazi" else "Job title") }, singleLine = true)
                OutlinedTextField(notes, { notes = it }, label = { Text(if (swahili) "Maelezo (hiari)" else "Notes (optional)") })
                OutlinedTextField(amount, { amount = it }, label = { Text("Expected payment (TSh)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(date, { date = it }, label = { Text("Date (YYYY-MM-DD)") }, singleLine = true)
            }
        },
        confirmButton = {
            Button(onClick = { onSave(title.trim(), notes.trim(), amount.toLongOrNull() ?: 0, date.trim()) },
                enabled = title.isNotBlank() && (amount.toLongOrNull() ?: -1) >= 0 && date.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) {
                Text(if (swahili) "Hifadhi" else "Save")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(if (swahili) "Ghairi" else "Cancel") } }
    )
}
